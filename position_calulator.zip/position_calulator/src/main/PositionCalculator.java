package main;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Logger;

import com.google.gson.Gson;

public class PositionCalculator 
{
	private static final Logger LOG = Logger.getLogger("PositionCalculator.class");
	
	public static void main(String[] args)
	{
		URL fileURL1 = PositionCalculator.class.getClass().getResource("../../resources/Input_StartOfDay_Positions.txt");
		URL fileURL2 = PositionCalculator.class.getClass().getResource("../../resources/Input_Transactions.txt");
		File startPositionsFile;
		File inputTransFile;
		List<Position> positionsList = new ArrayList<>();
		List<Transaction> transactionList = new ArrayList<>();
		
		try 
		{
			startPositionsFile = new File(fileURL1.toURI());
			inputTransFile = new File(fileURL2.toURI());
			
			BufferedReader reader1 = new BufferedReader(new FileReader(startPositionsFile));
			BufferedReader reader2 = new BufferedReader(new FileReader(inputTransFile));
			
			String headersLine = reader1.readLine();
			String positionsLine;
			while((positionsLine = reader1.readLine()) != null)
			{
				String[] positionsDetails = positionsLine.split(",");
				Position position = new Position();
				position.setInstrument(positionsDetails[0]);
				position.setAccount(Long.parseLong(positionsDetails[1]));
				position.setAccountType(positionsDetails[2]);
				position.setQuantity(Long.parseLong(positionsDetails[3]));
				positionsList.add(position);
			}
			
		    Scanner scanner = new Scanner(inputTransFile);
		    String text = scanner.useDelimiter("\\A").next();
		    
			Gson gson = new Gson();
			Transaction[] jsonData = gson.fromJson(text, Transaction[].class);
			
			transactionList = Arrays.asList(jsonData);
			
			for(Transaction transaction : transactionList)
			{
				if("B".equals(transaction.getTransactionType()))
				{
					for(Position position : positionsList)
					{
						if(transaction.getInstrument().equals(position.getInstrument()))
						{
							if("E".equals(position.getAccountType()))
							{
								Long newQuantity = position.getQuantity() + transaction.getTransactionQuantity();
								Long delta = newQuantity - position.getQuantity();
								position.setQuantity(newQuantity);
								position.setDelta(delta);
							}
							else if("I".equals(position.getAccountType()))
							{
								Long newQuantity = position.getQuantity() - transaction.getTransactionQuantity();
								Long delta = newQuantity - position.getQuantity();
								position.setQuantity(newQuantity);
								position.setDelta(delta);
							}
						}
					}
				}
				else if("S".equals(transaction.getTransactionType()))
				{
					for(Position position : positionsList)
					{
						if(transaction.getInstrument().equals(position.getInstrument()))
						{
							if("E".equals(position.getAccountType()))
							{
								Long newQuantity = position.getQuantity() - transaction.getTransactionQuantity();
								Long delta = newQuantity - position.getQuantity();
								position.setQuantity(newQuantity);
								position.setDelta(delta);
							}
							else if("I".equals(position.getAccountType()))
							{
								Long newQuantity = position.getQuantity() + transaction.getTransactionQuantity();
								Long delta = newQuantity - position.getQuantity();
								position.setQuantity(newQuantity);
								position.setDelta(delta);
							}
						}
					}
				}
			}
			
			File file = new File("src/resources/Expected_EndOfDay_Positions.txt");
			
			FileWriter fileWriter = new FileWriter(file);
			fileWriter.write(headersLine + ",Delta");
			fileWriter.write("\r\n");
			for(Position position : positionsList)
			{
				fileWriter.write(position.getInstrument() + ","
						+ position.getAccount() + ","
						+ position.getAccountType() + ","
						+ position.getQuantity() + ","
						+ position.getDelta());
				fileWriter.write("\r\n");
			}
			
			reader1.close();
			reader2.close();
			scanner.close();
			fileWriter.close();
		} 
		catch (URISyntaxException | IOException e) 
		{
			LOG.info("Unable to process " + e.getMessage());
		}
	}
}
