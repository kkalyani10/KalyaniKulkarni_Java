package main;

public class Transaction 
{
	private Long TransactionId;
	private String Instrument;
	private String TransactionType;
	private Long TransactionQuantity;
	
	public Long getTransactionId() 
	{
		return TransactionId;
	}
	
	public void setTransactionId(Long transactionId) 
	{
		this.TransactionId = transactionId;
	}
	
	public String getInstrument() 
	{
		return Instrument;
	}
	
	public void setInstrument(String instrument) 
	{
		this.Instrument = instrument;
	}
	
	public String getTransactionType() 
	{
		return TransactionType;
	}
	
	public void setTransactionType(String transactionType) 
	{
		this.TransactionType = transactionType;
	}
	
	public Long getTransactionQuantity() 
	{
		return TransactionQuantity;
	}
	
	public void setTransactionQuantity(Long transactionQuantity) 
	{
		this.TransactionQuantity = transactionQuantity;
	}
}
